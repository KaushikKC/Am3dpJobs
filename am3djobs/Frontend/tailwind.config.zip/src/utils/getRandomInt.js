export const getRandomInt = () => {
  return Math.floor(Math.random() * 10000000000);
};
