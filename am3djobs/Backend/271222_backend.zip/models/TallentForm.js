const mongoose = require('mongoose');

const TallentFormSchema = new mongoose.Schema({
    User_id: String,
    CompanyName: String,
    CompanyIndustry: String,
    CompanyHQ: String,
    CompanyUID: String,
    RecruiterName: String,
    RecruiterNumber: Number,
    JobDescription: String,
    JobTitle: String,
    JobMode: String,
    JobFunction: String,
    Skills: String,
    MonthlySalary: String,
    CandidateType: String,
    TypeOfWork: String,
    Background : String,
    JoiningTime: String,
    Interview: String,
    CompanyLogo: String,
});

const TallentForm = mongoose.model("TallentFormData", TallentFormSchema);
module.exports = TallentForm;