const mongoose = require('mongoose');

const CompanySchema = new mongoose.Schema({
    CompanyName: String,
    Title: String,
    Location: String,
    Number: Number,
    CandidateType: String,
    Background: String,
    TypeOfWork: String,
    MonthlySalary: Number,
    JobSpecialisation: String,
    RoleType: String,
    JobMode: String,
    JobFunction: String,
    JoiningTime: String,
    Interview: String,
    JobSkills: String,
    CompanyLogo: String,
});

const CompanyProfile = mongoose.model("JobFormData", CompanySchema);
module.exports = CompanyProfile;